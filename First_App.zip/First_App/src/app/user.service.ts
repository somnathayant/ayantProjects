import { Injectable, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import {UserMst} from '../app/user.model';
@Injectable()
export class UserService {
  

  constructor() {

  }
  getUserDetails(userMst:UserMst) {
     alert(userMst.description);
  }
}
