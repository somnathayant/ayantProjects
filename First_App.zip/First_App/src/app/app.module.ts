import { NgModule }      from '@angular/core';
import { FormsModule, ReactiveFormsModule }      from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppComponent }  from './app.component';
import { InputTextModule, ButtonModule,PanelModule,InputTextareaModule }  from 'primeng/primeng';
import {UserService} from '../app/user.service';
@NgModule({
  imports:      [ BrowserModule, BrowserAnimationsModule,InputTextareaModule, ReactiveFormsModule,
                  FormsModule, InputTextModule,ButtonModule,PanelModule ],
  declarations: [ AppComponent ],
  providers:[UserService],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
