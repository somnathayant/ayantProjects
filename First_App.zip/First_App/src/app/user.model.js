"use strict";
var UserMst = (function () {
    function UserMst() {
    }
    return UserMst;
}());
exports.UserMst = UserMst;
//# sourceMappingURL=user.model.js.map