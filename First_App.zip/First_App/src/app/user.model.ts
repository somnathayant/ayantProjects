export class UserMst {
    firstname: string;
    lastname:string;
    password:string;
    description:string;
   
}
