package com.ayantsoft.serv;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ayantsoft.hibernate.pojo.Address;
import com.ayantsoft.hibernate.pojo.Emp;

//@WebServlet("/SaveServlet")
public class SaveServlet extends HttpServlet {
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 3497529410411926673L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String name=request.getParameter("name");
		String password=request.getParameter("password");
		String email=request.getParameter("email");
		String state=request.getParameter("state");
		String pin=request.getParameter("pin");
		String city=request.getParameter("city");
		Address add=new Address();
		Emp e=new Emp();
		
		add.setCity(city);
		add.setPin(Integer.parseInt(pin));
		add.setState(state);
		e.setAddress(add);
		e.setEmail(email);
		e.setName(name);
		e.setPassword(password);
		
				int status=EmpDao.save(e,add);
			if(status>0){
				request.setAttribute("result","saved");
				request.getRequestDispatcher("Confirm.jsp").include(request, response);
			}else{
				request.setAttribute("result","not");
				request.getRequestDispatcher("Confirm.jsp").include(request, response);
			}
			
			out.close();
		}

}
