import { NgModule }      from '@angular/core';
import { FormsModule, ReactiveFormsModule }      from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppComponent }  from './app.component';
import { InputTextModule, ButtonModule,PanelModule,InputTextareaModule }  from 'primeng/primeng';

@NgModule({
  imports:      [ BrowserModule, BrowserAnimationsModule,InputTextareaModule, ReactiveFormsModule,
                  FormsModule, InputTextModule,ButtonModule,PanelModule ],
  declarations: [ AppComponent ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
