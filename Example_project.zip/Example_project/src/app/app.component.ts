import { Component,OnInit } from '@angular/core';
import { Validators,FormControl,FormGroup,FormBuilder } from '@angular/forms';


@Component({
  selector: 'my-app',
  templateUrl: 'app/appForm.html'
       
  
})
export class AppComponent implements OnInit { 
   
    
        userform: FormGroup;
        submitted: boolean;
        description: string;
        constructor(private fb: FormBuilder) {}
        ngOnInit() {
            this.userform = this.fb.group({
                'firstname': new FormControl('', Validators.required),
                'lastname': new FormControl('', Validators.required),
                'password': new FormControl('', Validators.compose([Validators.required, Validators.minLength(6)])),
                'description': new FormControl(''),
               
            });
   
     

    }
}
